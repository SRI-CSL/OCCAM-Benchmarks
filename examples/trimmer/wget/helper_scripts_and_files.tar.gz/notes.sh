apt-get install -y libgnutls28-dev

apt-get install libidn11-dev
apt-get install uuid-dev
apt-get install gnutls-bin

